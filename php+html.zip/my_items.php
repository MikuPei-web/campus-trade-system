<?php
session_start();
include("db_config.php");

if (!isset($_SESSION['email'])) {
    header("Location: login.html");
    exit();
}

$email = $_SESSION['email'];
$result = mysqli_query($conn, "SELECT * FROM items WHERE seller_email = '$email'");
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>My Items</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<h2 style="text-align:center;">🛒 My Items</h2>
<div class="item-container">
<?php while ($row = mysqli_fetch_assoc($result)) {
    $item_id = $row['id'];
    $orders = mysqli_query($conn, "SELECT * FROM orders WHERE item_id = $item_id");
    $ratings = mysqli_query($conn, "SELECT * FROM ratings WHERE item_id = $item_id");
?>
    <div class="item-card">
        <img src="<?php echo $row['image_url']; ?>" class="item-image">
        <h3><?php echo $row['name']; ?></h3>
        <p>狀態: <?php echo $row['is_available'] ? "上架中" : "已售出"; ?></p>
        <p>訂單數: <?php echo mysqli_num_rows($orders); ?></p>
        <p>評價數: <?php echo mysqli_num_rows($ratings); ?></p>
    </div>
<?php } ?>
</div>
</body>
</html>
