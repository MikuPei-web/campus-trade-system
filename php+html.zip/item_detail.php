<?php
session_start();
include("db_config.php");

if (!isset($_GET['item_id'])) {
    echo "No item selected.";
    exit();
}
$item_id = intval($_GET['item_id']);
$result = mysqli_query($conn, "SELECT i.*, u.email AS seller_email FROM item i JOIN user u ON i.seller_id = u.user_id WHERE item_id = $item_id");
if (!$result) {
    die("Failed to fetch item: " . mysqli_error($conn));
}
$row = mysqli_fetch_assoc($result);

$email = $_SESSION['email'] ?? '';
$already_ordered = false;
if ($email) {
    $order_result = mysqli_query($conn, "SELECT * FROM orders WHERE item_id = $item_id AND buyer_email = '$email'");
    $already_ordered = mysqli_num_rows($order_result) > 0;
}

$ratings_result = mysqli_query($conn, "SELECT * FROM ratings WHERE item_id = $item_id");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><?php echo $row['name']; ?></title>
    <style>
        body {
            font-family: sans-serif;
            background: #fdfbf8;
        }
        .detail-box {
            max-width: 540px;
            margin: 40px auto;
            padding: 24px;
            border: 1px solid #ccc;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            background-color: #fff;
            text-align: center;
        }
        .detail-box img {
            width: 100%;
            height: auto;
            border-radius: 10px;
            margin-bottom: 15px;
        }
        .detail-box h2 {
            margin-top: 0;
        }
        .info {
            margin: 10px 0;
        }
        .rating-form, .order-form {
            margin-top: 20px;
        }
        textarea, input[type='number'] {
            width: 90%;
            padding: 6px;
            margin-top: 5px;
        }
        button {
            margin-top: 12px;
            padding: 8px 16px;
            border: none;
            background-color: #4285F4;
            color: white;
            border-radius: 6px;
            cursor: pointer;
        }
        button:hover {
            background-color: #2f6ad6;
        }
        .rating-list {
            text-align: left;
            margin-top: 30px;
        }
        .rating-item {
            background: #f6f6f6;
            padding: 10px;
            border-radius: 8px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
<div class="detail-box">
    <h2><?php echo $row['name']; ?></h2>
    <img src="<?php echo $row['image_url']; ?>" alt="Item Image">
    <p class="info"><strong>Posted by:</strong> <?php echo $row['seller_email']; ?></p>
    <p class="info"><strong>Status:</strong> <?php echo $row['status']; ?></p>
    <p class="info"><strong>Description:</strong><br><?php echo $row['description']; ?></p>
    <p class="info"><strong>Price:</strong> <?php echo $row['price']; ?> RMB</p>

    <?php if (!$email): ?>
        <p style="color:red;">⚠️ Please log in to order or rate this item.</p>
    <?php elseif (!$already_ordered && $row['status'] === 'available'): ?>
        <form method="POST" action="place_order.php" class="order-form">
            <input type="hidden" name="item_id" value="<?php echo $item_id; ?>">
            <button type="submit">🛒 Order</button>
        </form>
    <?php elseif ($already_ordered): ?>
        <p style="color:green;">✅ You purchased this item</p>
        <form method="POST" action="submit_rating.php" class="rating-form">
            <label>⭐ Rating (1~5):</label>
            <input type="number" name="stars" min="1" max="5" required><br>
            <label>💬 Comment:</label><br>
            <textarea name="comment"></textarea>
            <input type="hidden" name="item_id" value="<?php echo $item_id; ?>">
            <input type="hidden" name="buyer_email" value="<?php echo $email; ?>">
            <button type="submit">Submit Rating</button>
        </form>
    <?php else: ?>
        <p style="color:red;">❌ This item is sold out.</p>
    <?php endif; ?>

    <div class="rating-list">
        <h3>⭐ Ratings</h3>
        <?php if (mysqli_num_rows($ratings_result) === 0): ?>
            <p>No ratings yet.</p>
        <?php endif; ?>
        <?php while ($r = mysqli_fetch_assoc($ratings_result)): ?>
            <div class="rating-item">
                <strong><?php echo $r['buyer_email']; ?>:</strong><br>
                <?php echo str_repeat("⭐", (int)$r['stars']); ?><br>
                <?php echo htmlspecialchars($r['comment']); ?>
            </div>
        <?php endwhile; ?>
    </div>
</div>
</body>
</html>
