<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Campus Second-hand Trading Platform</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #fdfbf8;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }
    .box {
      text-align: center;
      background: white;
      padding: 40px 60px;
      border-radius: 16px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    }
    h1 {
      font-size: 24px;
      margin-bottom: 6px;
    }
    p {
      color: #666;
      margin-bottom: 20px;
    }
    button {
      padding: 10px 20px;
      margin: 10px;
      font-size: 16px;
      border: none;
      background-color: #4285F4;
      color: white;
      border-radius: 6px;
      cursor: pointer;
    }
    button:hover {
      background-color: #3367D6;
    }
  </style>
</head>
<body>
  <div class="box">
    <h1>🎓 Campus Second-hand Trading Platform</h1>
    <p>Welcome, <?php echo $_SESSION['email']; ?>!</p>
    <button onclick="location.href='item_list.php'">Browse Items</button>
    <button onclick="location.href='post_item.php'">Post Item</button>
    <button onclick="location.href='my_orders.php'">My Orders</button>
    <button onclick="location.href='my_messages.php'">Messages</button>
    <button onclick="location.href='logout.php'">Logout</button>
  </div>
</body>
</html>
