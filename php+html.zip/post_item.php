<?php
session_start();
include("db_config.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $category = mysqli_real_escape_string($conn, $_POST['category']);
    $price = floatval($_POST['price']);
    $image_url = mysqli_real_escape_string($conn, $_POST['image_url']);

    $sql = "INSERT INTO item (seller_id, name, description, category, price, image_url, status)
            VALUES ($user_id, '$name', '$description', '$category', $price, '$image_url', 'available')";

    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Item posted successfully!'); window.location.href='index.php';</script>";
    } else {
        echo "❌ Error: " . mysqli_error($conn);
    }
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Post Item</title>
    <style>
        body { font-family: sans-serif; background-color: #fdfbf8; }
        .form-box {
            max-width: 500px; margin: 60px auto; padding: 24px;
            background: white; border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        h2 { text-align: center; }
        input, textarea {
            width: 100%; padding: 10px; margin-top: 10px;
            border-radius: 6px; border: 1px solid #ccc;
        }
        button {
            margin-top: 16px; padding: 10px 20px;
            background-color: #4285F4; color: white;
            border: none; border-radius: 6px; cursor: pointer;
        }
        button:hover { background-color: #3367D6; }
    </style>
</head>
<body>
<div class="form-box">
    <h2>📦 Post New Item</h2>
    <form method="POST">
        <input type="text" name="name" placeholder="Item name" required>
        <textarea name="description" placeholder="Description" required></textarea>
        <input type="text" name="category" placeholder="Category" required>
        <input type="number" step="0.01" name="price" placeholder="Price" required>
        <input type="text" name="image_url" placeholder="Image path (e.g., images/backpack.jpg)" required>
        <button type="submit">Submit</button>
    </form>
</div>
</body>
</html>
