<?php
session_start();
include("db_config.php");

if (!isset($_SESSION['user_id']) || !isset($_GET['to_user'])) {
    echo "⚠️ Login required or recipient not set.";
    exit();
}

$from_user = $_SESSION['user_id'];
$to_user = intval($_GET['to_user']);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $content = mysqli_real_escape_string($conn, $_POST['content']);
    $sql = "INSERT INTO message (from_user, to_user, content, message_time)
            VALUES ($from_user, $to_user, '$content', NOW())";

    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Message sent!'); window.location.href='my_messages.php';</script>";
    } else {
        echo "❌ Error: " . mysqli_error($conn);
    }
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>✉️ Reply Message</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #fdfbf8;
        }
        .form-box {
            max-width: 500px;
            margin: 80px auto;
            padding: 24px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            text-align: center;
        }
        textarea {
            width: 100%;
            height: 120px;
            padding: 10px;
            margin-bottom: 12px;
            border-radius: 6px;
            border: 1px solid #ccc;
            resize: none;
        }
        button {
            padding: 8px 16px;
            background-color: #4285F4;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }
        button:hover {
            background-color: #3367D6;
        }
    </style>
</head>
<body>
<div class="form-box">
    <h2>✉️ Reply to Message</h2>
    <form method="POST">
        <textarea name="content" required placeholder="Type your message here..."></textarea><br>
        <button type="submit">Send</button>
    </form>
</div>
</body>
</html>
