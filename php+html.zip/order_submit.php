<?php
session_start();
include("db_config.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['item_id'])) {
    $user_id = $_SESSION['user_id'];
    $item_id = intval($_POST['item_id']);

    // Create the order
    $sql = "INSERT INTO orders (item_id, buyer_id, created_at) VALUES ($item_id, $user_id, NOW())";
    mysqli_query($conn, $sql);

    // Mark item as unavailable
    mysqli_query($conn, "UPDATE items SET is_available = 0, status='sold' WHERE item_id = $item_id");

    header("Location: my_orders.php");
    exit();
}
?>
