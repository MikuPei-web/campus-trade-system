<?php
session_start();
include("db_config.php");

if (!isset($_SESSION['user_id']) || !isset($_GET['order_id'])) {
    header("Location: login.html");
    exit();
}

$order_id = intval($_GET['order_id']);

// Check if already rated
$check = mysqli_query($conn, "SELECT * FROM ratings WHERE order_id = $order_id");
if (mysqli_num_rows($check) > 0) {
    echo "You already rated this item.";
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Rate Your Order</title>
</head>
<body>
    <h2>⭐ Rate Your Order</h2>
    <form action="review_submit.php" method="post">
        <input type="hidden" name="order_id" value="<?php echo $order_id; ?>">
        <label for="stars">Stars (1-5):</label>
        <input type="number" name="stars" min="1" max="5" required><br><br>
        <label for="comment">Comment:</label><br>
        <textarea name="comment" rows="4" cols="40"></textarea><br>
        <button type="submit">Submit Rating</button>
    </form>
</body>
</html>
