<?php
session_start();
include("db_config.php");

$email = $_POST['email'];
$password = $_POST['password'];

$query = "SELECT * FROM user WHERE email='$email' AND password='$password'";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) === 1) {
    $user = mysqli_fetch_assoc($result);
    $_SESSION['email'] = $email;
    $_SESSION['user_id'] = $user['user_id'];
    header("Location: index.php"); // ✅ 登入成功導回首頁
    exit();
} else {
    echo "<script>alert('Login failed. Please try again.'); window.location.href='login.html';</script>";
}
?>
