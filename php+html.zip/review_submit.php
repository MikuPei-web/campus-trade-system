<?php
session_start();
include("db_config.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $order_id = intval($_POST['order_id']);
    $stars = intval($_POST['stars']);
    $comment = mysqli_real_escape_string($conn, $_POST['comment']);
    $user_id = $_SESSION['user_id'];

    $sql = "INSERT INTO ratings (order_id, user_id, stars, comment, created_at)
            VALUES ($order_id, $user_id, $stars, '$comment', NOW())";
    mysqli_query($conn, $sql);

    header("Location: my_orders.php");
    exit();
}
?>
