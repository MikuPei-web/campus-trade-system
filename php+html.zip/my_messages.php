<?php
session_start();
include("db_config.php");

if (!isset($_SESSION['user_id'])) {
    echo "⚠️ Please log in first.";
    exit();
}
$user_id = $_SESSION['user_id'];

$query = "SELECT m.*, u.email AS sender_email
          FROM message m
          JOIN user u ON m.from_user = u.user_id
          WHERE m.to_user = $user_id
          ORDER BY m.message_time DESC";

$result = mysqli_query($conn, $query);
if (!$result) {
    die("❌ SQL Error: " . mysqli_error($conn));
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>📨 My Messages</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #fdfbf8;
        }
        .container {
            max-width: 800px;
            margin: 40px auto;
            padding: 20px;
        }
        h2 {
            text-align: center;
            margin-bottom: 30px;
        }
        .msg-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
            padding: 16px;
            margin-bottom: 20px;
        }
        .msg-card p {
            margin: 8px 0;
        }
        .reply-btn {
            display: inline-block;
            padding: 6px 12px;
            background-color: #4285F4;
            color: white;
            text-decoration: none;
            border-radius: 6px;
        }
        .reply-btn:hover {
            background-color: #3367D6;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>📨 My Messages</h2>
    <?php if (mysqli_num_rows($result) === 0): ?>
        <p style="text-align:center;">You have no messages yet.</p>
    <?php endif; ?>
    <?php while ($row = mysqli_fetch_assoc($result)): ?>
        <div class="msg-card">
            <p><strong>From:</strong> <?php echo $row['sender_email']; ?></p>
            <p><strong>Message:</strong><br><?php echo htmlspecialchars($row['content']); ?></p>
            <p><strong>Time:</strong> <?php echo $row['message_time']; ?></p>
            <a class="reply-btn" href="reply_message.php?to_user=<?php echo $row['from_user']; ?>">Reply</a>
        </div>
    <?php endwhile; ?>
</div>
</body>
</html>
