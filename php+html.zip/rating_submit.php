<?php
session_start();
include("db_config.php");

if (!isset($_SESSION['email'])) {
    header("Location: login.html");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $item_id = $_POST['item_id'];
    $stars = $_POST['stars'];
    $comment = $_POST['comment'];
    $buyer = $_SESSION['email'];

    // 檢查是否已評價過
    $check = mysqli_query($conn, "SELECT * FROM ratings WHERE item_id = $item_id AND buyer_email = '$buyer'");
    if (mysqli_num_rows($check) == 0) {
        $sql = "INSERT INTO ratings (item_id, buyer_email, stars, comment, rating_time) 
                VALUES ($item_id, '$buyer', $stars, '$comment', NOW())";
        mysqli_query($conn, $sql);
    }

    header("Location: my_orders.php");
    exit();
}
?>