<?php
session_start();
include("db_config.php");

$result = mysqli_query($conn, "SELECT * FROM item WHERE status = 'available'");
if (!$result) {
    die("SQL Error: " . mysqli_error($conn));
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Item List</title>
    <style>
        body {
            font-family: sans-serif;
            background-color: #f8f9fa;
        }
        .container {
            max-width: 960px;
            margin: 40px auto;
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 24px;
        }
        .card {
            width: 220px;
            border: 1px solid #ccc;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            padding: 16px;
            background-color: #fff;
            text-align: center;
        }
        .card img {
            width: 100%;
            height: 150px;
            object-fit: cover;
            border-radius: 8px;
            margin-bottom: 10px;
        }
        .card h3 {
            font-size: 18px;
            margin: 5px 0;
        }
        .card p {
            margin: 4px 0;
        }
        .card a {
            display: inline-block;
            margin-top: 8px;
            padding: 6px 12px;
            background-color: #4285F4;
            color: white;
            border-radius: 6px;
            text-decoration: none;
        }
        .card a:hover {
            background-color: #2f6ad6;
        }
    </style>
</head>
<body>
    <h2 style="text-align:center;">📦 Browse Available Items</h2>
    <div class="container">
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <div class="card">
                <img src="<?php echo $row['image_url']; ?>" alt="Item Image">
                <h3><?php echo htmlspecialchars($row['name']); ?></h3>
                <p><?php echo $row['price']; ?> RMB</p>
                <a href="item_detail.php?item_id=<?php echo $row['item_id']; ?>">View</a>
            </div>
        <?php } ?>
    </div>
</body>
</html>
