<?php
session_start();
include("db_config.php");

$email = $_SESSION['email'] ?? '';
if (!$email) {
    echo "⚠️ Please log in first.";
    exit();
}

$result = mysqli_query($conn, "SELECT o.*, i.name, i.image_url FROM orders o JOIN item i ON o.item_id = i.item_id WHERE o.buyer_email = '$email'");
if (!$result) {
    die("❌ Failed to load orders: " . mysqli_error($conn));
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>📦 My Orders</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #fdfbf8;
        }
        .container {
            max-width: 800px;
            margin: 40px auto;
            padding: 20px;
        }
        .title {
            text-align: center;
            margin-bottom: 30px;
        }
        .order-card {
            display: flex;
            gap: 20px;
            background: #fff;
            padding: 16px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            align-items: center;
        }
        .order-card img {
            width: 120px;
            height: 120px;
            object-fit: cover;
            border-radius: 10px;
            border: 1px solid #ccc;
        }
        .order-info {
            flex: 1;
        }
        .order-info h3 {
            margin: 0 0 6px;
        }
        .order-info p {
            margin: 4px 0;
            color: #444;
        }
        .rate-btn {
            padding: 8px 14px;
            background-color: #4285F4;
            color: white;
            text-decoration: none;
            border-radius: 6px;
        }
        .rate-btn:hover {
            background-color: #3367D6;
        }
    </style>
</head>
<body>
<div class="container">
    <h2 class="title">🧾 My Order History</h2>
    <?php while ($row = mysqli_fetch_assoc($result)) { ?>
        <div class="order-card">
            <img src="<?php echo $row['image_url']; ?>" alt="Item">
            <div class="order-info">
                <h3><?php echo $row['name']; ?></h3>
                <p><strong>Order Date:</strong> <?php echo $row['order_time']; ?></p>
                <a class="rate-btn" href="item_detail.php?item_id=<?php echo $row['item_id']; ?>">Rate this item ➡️</a>
            </div>
        </div>
    <?php } ?>
</div>
</body>
</html>
